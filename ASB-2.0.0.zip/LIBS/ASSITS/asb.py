# pip install PySide6 cryptography psutil
import sys, os, subprocess, json, base64, datetime, random
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QFileDialog, QPlainTextEdit,
    QVBoxLayout, QWidget, QMessageBox, QMenuBar, QMenu,
    QWidgetAction, QSizePolicy, QToolBar, QHBoxLayout, QLabel, QPushButton,
    QDialog, QLineEdit, QDialogButtonBox, QTextEdit, QStatusBar,
    QListWidget, QComboBox, QSpinBox, QCheckBox, QTabWidget, QGroupBox,
    QFontDialog, QColorDialog, QInputDialog
)
from PySide6.QtGui import QAction, QSyntaxHighlighter, QTextCharFormat, QColor, QFont, QKeySequence, QTextCursor, QPainter, QTextFormat, QTextBlock
from PySide6.QtCore import Qt, QRegularExpression, QRect, QSize, QTimer, QProcess
import multiprocessing
import threading
import psutil

# ==================== SETTINGS SYSTEM ====================
class SettingsSystem:
    def __init__(self, editor):
        self.editor = editor
        self.settings_dir = os.path.dirname(os.path.abspath(__file__))
        self.settings_file = os.path.join(self.settings_dir, "settings.enc")
        self.backup_file = os.path.join(self.settings_dir, "settings_backup.enc")
        self.passcode_file = os.path.join(self.settings_dir, "passcode.enc")
        self.default_settings = {
            "font_family": "Consolas",
            "font_size": 14,
            "default_file_type": "ASB Files (*.asb)",
            "developer_mode": False,
            "large_file_threshold": 10000,
            "enable_multiprocess": True,
            "auto_save": False,
            "line_numbers": True,
            "word_wrap": False,
            "show_whitespace": False,
            "tab_size": 4,
            "theme": "dark"
        }
        self.load_settings()
        
    def load_settings(self):
        """Load settings from encrypted file"""
        try:
            if os.path.exists(self.settings_file):
                with open(self.settings_file, 'r') as f:
                    encoded_data = f.read().strip()
                
                json_data = base64.b64decode(encoded_data.encode()).decode()
                loaded_settings = json.loads(json_data)
                self.settings = {**self.default_settings, **loaded_settings}
                print(f"✅ Settings loaded from: {self.settings_file}")
            else:
                self.settings = self.default_settings.copy()
                self.save_settings()
                
        except Exception as e:
            print(f"❌ Settings load error: {e}")
            self.settings = self.default_settings.copy()
            self.save_settings()
    
    def save_settings(self):
        """Save settings to encrypted file"""
        try:
            if os.path.exists(self.settings_file):
                with open(self.settings_file, 'r') as source:
                    with open(self.backup_file, 'w') as backup:
                        backup.write(source.read())
                print(f"✅ Settings backed up to: {self.backup_file}")
            
            json_data = json.dumps(self.settings, indent=4)
            encoded_data = base64.b64encode(json_data.encode()).decode()
            
            with open(self.settings_file, 'w') as f:
                f.write(encoded_data)
            print(f"✅ Settings saved to: {self.settings_file}")
            
        except Exception as e:
            print(f"❌ Error saving settings: {e}")
    
    def restore_backup(self):
        """Restore settings from backup"""
        try:
            if os.path.exists(self.backup_file):
                with open(self.backup_file, 'r') as f:
                    encoded_data = f.read().strip()
                
                json_data = base64.b64decode(encoded_data.encode()).decode()
                loaded_settings = json.loads(json_data)
                self.settings = {**self.default_settings, **loaded_settings}
                self.save_settings()
                print(f"✅ Settings restored from backup")
                return True
            else:
                print("❌ No backup file found")
                return False
                
        except Exception as e:
            print(f"❌ Error restoring backup: {e}")
            return False
    
    def get_developer_password(self):
        """Load developer password from encrypted file"""
        try:
            if os.path.exists(self.passcode_file):
                with open(self.passcode_file, 'r') as f:
                    encoded_data = f.read().strip()
                
                json_data = base64.b64decode(encoded_data.encode()).decode()
                password_data = json.loads(json_data)
                return password_data.get('password', 'ASBDEV1432')  # Default fallback
            else:
                # Create default password file
                default_password = "ASBDEV1432"
                self.save_developer_password(default_password)
                return default_password
        except Exception as e:
            print(f"❌ Password load error: {e}")
            return "ASBDEV1432"  # Default fallback
    
    def save_developer_password(self, password):
        """Save developer password to encrypted file"""
        try:
            password_data = {
                'password': password,
                'signature': 'ASB_PASSCODE_2024'
            }
            
            json_data = json.dumps(password_data)
            encoded_data = base64.b64encode(json_data.encode()).decode()
            
            with open(self.passcode_file, 'w') as f:
                f.write(encoded_data)
            print(f"✅ Developer password saved to: {self.passcode_file}")
            
        except Exception as e:
            print(f"❌ Error saving password: {e}")
    
    def get(self, key):
        return self.settings.get(key, self.default_settings.get(key))
    
    def set(self, key, value):
        self.settings[key] = value
        self.save_settings()

# ==================== SETTINGS DIALOG ====================
class SettingsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.editor = parent
        self.settings_system = parent.settings_system
        self.setWindowTitle("Editor Settings")
        self.setModal(True)
        self.setFixedSize(600, 500)
        
        layout = QVBoxLayout(self)
        
        tabs = QTabWidget()
        
        general_tab = QWidget()
        general_layout = QVBoxLayout(general_tab)
        
        font_group = QGroupBox("Font Settings")
        font_layout = QVBoxLayout(font_group)
        
        font_family_layout = QHBoxLayout()
        font_family_layout.addWidget(QLabel("Font Family:"))
        self.font_family_combo = QComboBox()
        self.font_family_combo.addItems(["Consolas", "Courier New", "Monaco", "Menlo", "Source Code Pro", "Fira Code", "Cascadia Code", "JetBrains Mono"])
        self.font_family_combo.setCurrentText(self.settings_system.get("font_family"))
        font_family_layout.addWidget(self.font_family_combo)
        
        self.font_picker_btn = QPushButton("Pick Font...")
        self.font_picker_btn.clicked.connect(self.pick_font)
        font_family_layout.addWidget(self.font_picker_btn)
        font_layout.addLayout(font_family_layout)
        
        font_size_layout = QHBoxLayout()
        font_size_layout.addWidget(QLabel("Font Size:"))
        self.font_size_spin = QSpinBox()
        self.font_size_spin.setRange(8, 72)
        self.font_size_spin.setValue(self.settings_system.get("font_size"))
        font_size_layout.addWidget(self.font_size_spin)
        font_layout.addLayout(font_size_layout)
        
        general_layout.addWidget(font_group)
        
        file_group = QGroupBox("File Settings")
        file_layout = QVBoxLayout(file_group)
        
        file_type_layout = QHBoxLayout()
        file_type_layout.addWidget(QLabel("Default File Type:"))
        self.file_type_combo = QComboBox()
        self.file_type_combo.addItems([
            "ASB Files (*.asb)",
            "All Files (*)",
            "Python Files (*.py)",
            "Text Files (*.txt)",
            "JavaScript Files (*.js)",
            "HTML Files (*.html *.htm)",
            "CSS Files (*.css)",
            "JSON Files (*.json)"
        ])
        self.file_type_combo.setCurrentText(self.settings_system.get("default_file_type"))
        file_type_layout.addWidget(self.file_type_combo)
        file_layout.addLayout(file_type_layout)
        
        self.auto_save_check = QCheckBox("Enable Auto Save")
        self.auto_save_check.setChecked(self.settings_system.get("auto_save"))
        file_layout.addWidget(self.auto_save_check)
        
        general_layout.addWidget(file_group)
        
        editor_group = QGroupBox("Editor Settings")
        editor_layout = QVBoxLayout(editor_group)
        
        self.line_numbers_check = QCheckBox("Show Line Numbers")
        self.line_numbers_check.setChecked(self.settings_system.get("line_numbers"))
        editor_layout.addWidget(self.line_numbers_check)
        
        self.word_wrap_check = QCheckBox("Enable Word Wrap")
        self.word_wrap_check.setChecked(self.settings_system.get("word_wrap"))
        editor_layout.addWidget(self.word_wrap_check)
        
        self.whitespace_check = QCheckBox("Show Whitespace")
        self.whitespace_check.setChecked(self.settings_system.get("show_whitespace"))
        editor_layout.addWidget(self.whitespace_check)
        
        tab_layout = QHBoxLayout()
        tab_layout.addWidget(QLabel("Tab Size:"))
        self.tab_size_spin = QSpinBox()
        self.tab_size_spin.setRange(2, 8)
        self.tab_size_spin.setValue(self.settings_system.get("tab_size"))
        tab_layout.addWidget(self.tab_size_spin)
        editor_layout.addLayout(tab_layout)
        
        general_layout.addWidget(editor_group)
        
        perf_group = QGroupBox("Performance Settings")
        perf_layout = QVBoxLayout(perf_group)
        
        large_file_layout = QHBoxLayout()
        large_file_layout.addWidget(QLabel("Large File Threshold (lines):"))
        self.large_file_spin = QSpinBox()
        self.large_file_spin.setRange(1000, 100000)
        self.large_file_spin.setValue(self.settings_system.get("large_file_threshold"))
        large_file_layout.addWidget(self.large_file_spin)
        perf_layout.addLayout(large_file_layout)
        
        self.multiprocess_check = QCheckBox("Enable Multi-process Support")
        self.multiprocess_check.setChecked(self.settings_system.get("enable_multiprocess"))
        perf_layout.addWidget(self.multiprocess_check)
        
        general_layout.addWidget(perf_group)
        general_layout.addStretch()
        
        developer_tab = QWidget()
        developer_layout = QVBoxLayout(developer_tab)
        
        dev_group = QGroupBox("🔧 ASB Developer Mode")
        dev_layout = QVBoxLayout(dev_group)
        
        dev_info = QLabel("Developer mode unlocks full control over the editor, including UI customization, advanced features, and system access.")
        dev_info.setWordWrap(True)
        dev_info.setStyleSheet("color: #666; font-style: italic;")
        dev_layout.addWidget(dev_info)
        
        password_layout = QHBoxLayout()
        password_layout.addWidget(QLabel("Developer Password:"))
        self.password_input = QLineEdit()
        self.password_input.setEchoMode(QLineEdit.Password)
        self.password_input.setPlaceholderText("Enter ASB developer password")
        password_layout.addWidget(self.password_input)
        dev_layout.addLayout(password_layout)
        
        self.enable_dev_btn = QPushButton("🚀 Enable Developer Mode")
        self.enable_dev_btn.clicked.connect(self.enable_developer_mode)
        self.enable_dev_btn.setStyleSheet("""
            QPushButton {
                background: #ff6b35; 
                color: white; 
                font-weight: bold;
                padding: 10px;
                border: none;
                border-radius: 5px;
                font-size: 14px;
            }
            QPushButton:hover {
                background: #e55a2b;
            }
        """)
        dev_layout.addWidget(self.enable_dev_btn)
        
        change_pass_layout = QHBoxLayout()
        self.new_password_input = QLineEdit()
        self.new_password_input.setEchoMode(QLineEdit.Password)
        self.new_password_input.setPlaceholderText("Enter new developer password")
        change_pass_layout.addWidget(self.new_password_input)
        
        self.change_pass_btn = QPushButton("Change Password")
        self.change_pass_btn.clicked.connect(self.change_developer_password)
        self.change_pass_btn.setStyleSheet("""
            QPushButton {
                background: #2196F3; 
                color: white; 
                padding: 5px 10px;
                border: none;
                border-radius: 3px;
            }
        """)
        change_pass_layout.addWidget(self.change_pass_btn)
        dev_layout.addLayout(change_pass_layout)
        
        self.dev_status_label = QLabel()
        self.update_dev_status()
        dev_layout.addWidget(self.dev_status_label)
        
        features_label = QLabel("🛠️ Developer Features:")
        features_label.setStyleSheet("font-weight: bold; margin-top: 10px;")
        dev_layout.addWidget(features_label)
        
        features_list = QLabel("• Full UI Control\n• Advanced Debugging\n• System Access\n• Plugin System\n• Custom Themes\n• Code Injection\n• Performance Tools\n• File Operations")
        features_list.setStyleSheet("color: #555;")
        dev_layout.addWidget(features_list)
        
        developer_layout.addWidget(dev_group)
        developer_layout.addStretch()
        
        tabs.addTab(general_tab, "General")
        tabs.addTab(developer_tab, "Developer")
        
        layout.addWidget(tabs)
        
        button_layout = QHBoxLayout()
        self.apply_btn = QPushButton("Apply")
        self.apply_btn.clicked.connect(self.apply_settings)
        self.apply_btn.setStyleSheet("background: #4CAF50; color: white; font-weight: bold; padding: 8px 15px;")
        
        self.ok_btn = QPushButton("OK")
        self.ok_btn.clicked.connect(self.ok_clicked)
        self.ok_btn.setStyleSheet("background: #2196F3; color: white; font-weight: bold; padding: 8px 15px;")
        
        self.cancel_btn = QPushButton("Cancel")
        self.cancel_btn.clicked.connect(self.close)
        self.cancel_btn.setStyleSheet("padding: 8px 15px;")
        
        button_layout.addWidget(self.apply_btn)
        button_layout.addWidget(self.ok_btn)
        button_layout.addWidget(self.cancel_btn)
        layout.addLayout(button_layout)
    
    def pick_font(self):
        current_font = QFont(self.settings_system.get("font_family"), self.settings_system.get("font_size"))
        font, ok = QFontDialog.getFont(current_font, self)
        if ok:
            self.font_family_combo.setCurrentText(font.family())
            self.font_size_spin.setValue(font.pointSize())
    
    def update_dev_status(self):
        if self.settings_system.get("developer_mode"):
            self.dev_status_label.setText("🟢 Developer Mode: ENABLED - Full Access Granted")
            self.dev_status_label.setStyleSheet("color: green; font-weight: bold; background: #e8f5e8; padding: 5px; border-radius: 3px;")
        else:
            self.dev_status_label.setText("🔴 Developer Mode: DISABLED - Limited Access")
            self.dev_status_label.setStyleSheet("color: red; background: #ffe8e8; padding: 5px; border-radius: 3px;")
    
    def enable_developer_mode(self):
        password = self.password_input.text().strip()
        correct_password = self.settings_system.get_developer_password()
        
        if password == correct_password:
            self.settings_system.set("developer_mode", True)
            self.update_dev_status()
            QMessageBox.information(self, "Developer Mode", 
                                  "🎉 Developer Mode Enabled!\n\n"
                                  "You now have full access to:\n"
                                  "• All UI controls\n• Advanced debugging\n• System operations\n"
                                  "• Plugin system\n• Performance tools\n• File management")
            self.password_input.clear()
            if self.editor:
                self.editor._add_developer_menu()
        else:
            QMessageBox.warning(self, "Access Denied", "❌ Incorrect developer password!")
    
    def change_developer_password(self):
        new_password = self.new_password_input.text().strip()
        if new_password:
            self.settings_system.save_developer_password(new_password)
            QMessageBox.information(self, "Password Changed", "✅ Developer password updated successfully!")
            self.new_password_input.clear()
        else:
            QMessageBox.warning(self, "Error", "❌ Please enter a new password!")
    
    def apply_settings(self):
        font_family = self.font_family_combo.currentText()
        font_size = self.font_size_spin.value()
        
        self.settings_system.set("font_family", font_family)
        self.settings_system.set("font_size", font_size)
        self.settings_system.set("default_file_type", self.file_type_combo.currentText())
        self.settings_system.set("auto_save", self.auto_save_check.isChecked())
        self.settings_system.set("line_numbers", self.line_numbers_check.isChecked())
        self.settings_system.set("word_wrap", self.word_wrap_check.isChecked())
        self.settings_system.set("show_whitespace", self.whitespace_check.isChecked())
        self.settings_system.set("tab_size", self.tab_size_spin.value())
        self.settings_system.set("large_file_threshold", self.large_file_spin.value())
        self.settings_system.set("enable_multiprocess", self.multiprocess_check.isChecked())
        
        if self.editor:
            self.editor.apply_settings()
        
        QMessageBox.information(self, "Settings", "✅ Settings applied successfully!")
    
    def ok_clicked(self):
        self.apply_settings()
        self.close()

# ==================== DEVELOPER TOOLS ====================
class DeveloperTools:
    def __init__(self, editor):
        self.editor = editor
    
    def show_system_info(self):
        try:
            import platform
            system_info = f"""
🤖 SYSTEM INFORMATION:

💻 Platform: {platform.system()} {platform.release()}
🐍 Python: {platform.python_version()}
🧠 CPU Cores: {psutil.cpu_count()}
📊 Memory: {psutil.virtual_memory().total // (1024**3)} GB
💾 Disk Usage: {psutil.disk_usage('/').percent}%

📁 Editor Stats:
• Open Files: {len(self.editor.open_files)}
• Current Theme: {self.editor.current_theme}
• Developer Mode: {self.editor.settings_system.get('developer_mode')}
• Font: {self.editor.settings_system.get('font_family')} {self.editor.settings_system.get('font_size')}pt
"""
            QMessageBox.information(self.editor, "System Info", system_info)
        except Exception as e:
            QMessageBox.warning(self.editor, "Error", f"Could not get system info: {e}")
    
    def performance_monitor(self):
        process = psutil.Process()
        memory_mb = process.memory_info().rss / 1024 / 1024
        cpu_percent = process.cpu_percent()
        
        metrics = f"""
📊 PERFORMANCE METRICS:

🧠 Memory Usage: {memory_mb:.1f} MB
⚡ CPU Usage: {cpu_percent:.1f}%
📁 Open Files: {len(self.editor.open_files)}
🔧 Threads: {process.num_threads()}
"""
        QMessageBox.information(self.editor, "Performance", metrics)
    
    def export_all_data(self):
        try:
            export_dir = QFileDialog.getExistingDirectory(self.editor, "Select Export Directory")
            if export_dir:
                settings_file = os.path.join(export_dir, "settings_backup.enc")
                if os.path.exists(self.editor.settings_system.settings_file):
                    with open(self.editor.settings_system.settings_file, 'r') as source:
                        with open(settings_file, 'w') as dest:
                            dest.write(source.read())
                
                files_dir = os.path.join(export_dir, "exported_files")
                os.makedirs(files_dir, exist_ok=True)
                
                for filename, content in self.editor.open_files.items():
                    safe_name = os.path.basename(filename).replace('..', '_')
                    export_path = os.path.join(files_dir, safe_name)
                    with open(export_path, 'w', encoding='utf-8') as f:
                        f.write(content)
                
                QMessageBox.information(self.editor, "Export Complete", 
                                      f"✅ All data exported to:\n{export_dir}")
        except Exception as e:
            QMessageBox.warning(self.editor, "Export Error", f"Could not export: {e}")
    
    def custom_theme_creator(self):
        if not self.editor.settings_system.get("developer_mode"):
            QMessageBox.warning(self.editor, "Access Denied", "Developer mode required!")
            return
            
        name, ok = QInputDialog.getText(self.editor, "Theme Creator", "Enter theme name:")
        if not ok or not name:
            return
            
        bg_color = QColorDialog.getColor(QColor("#1e1e1e"), self.editor, "Select Background Color")
        if not bg_color.isValid():
            return
            
        text_color = QColorDialog.getColor(QColor("#d4d4d4"), self.editor, "Select Text Color")
        if not text_color.isValid():
            return

        # Create more comprehensive CSS for the theme
        theme_css = f"""
        QPlainTextEdit {{
            background: {bg_color.name()};
            color: {text_color.name()};
            font-family: {self.editor.settings_system.get('font_family')};
            font-size: {self.editor.settings_system.get('font_size')}pt;
            border: none;
        }}
        QMainWindow {{
            background: {bg_color.name()};
        }}
        QMenuBar {{
            background: {self._darken_color(bg_color.name())};
            color: {text_color.name()};
            border: none;
        }}
        QMenuBar::item {{
            background: transparent;
            padding: 5px 10px;
        }}
        QMenuBar::item:selected {{
            background: {self._lighten_color(bg_color.name())};
        }}
        QMenu {{
            background: {self._darken_color(bg_color.name())};
            color: {text_color.name()};
            border: 1px solid {self._lighten_color(bg_color.name())};
        }}
        QMenu::item {{
            padding: 5px 20px;
        }}
        QMenu::item:selected {{
            background: {self._lighten_color(bg_color.name())};
        }}
        QToolBar {{
            background: {self._darken_color(bg_color.name())};
            border: none;
            padding: 2px;
        }}
        QStatusBar {{
            background: {self._darken_color(bg_color.name())};
            color: {text_color.name()};
        }}
        """
        
        themes_dir = os.path.join(self.editor.settings_system.settings_dir, "themes")
        os.makedirs(themes_dir, exist_ok=True)
        theme_file = os.path.join(themes_dir, f"{name}.json")
        
        theme_data = {
            "name": name,
            "background": bg_color.name(),
            "text_color": text_color.name(),
            "css": theme_css
        }
        
        with open(theme_file, 'w') as f:
            json.dump(theme_data, f, indent=2)
            
        QMessageBox.information(self.editor, "Theme Created", f"🎨 Theme '{name}' saved!\n\nYou can now load it from the Themes menu.")
    
    def _darken_color(self, color_hex, factor=0.8):
        """Darken a hex color"""
        color = QColor(color_hex)
        color = color.darker(int(100 + (100 - 100 * factor)))
        return color.name()
    
    def _lighten_color(self, color_hex, factor=1.2):
        """Lighten a hex color"""
        color = QColor(color_hex)
        color = color.lighter(int(100 * factor))
        return color.name()
    
    def load_custom_themes(self):
        """Load all custom themes from the themes directory"""
        themes_dir = os.path.join(self.editor.settings_system.settings_dir, "themes")
        custom_themes = []
        
        if os.path.exists(themes_dir):
            for filename in os.listdir(themes_dir):
                if filename.endswith('.json'):
                    theme_path = os.path.join(themes_dir, filename)
                    try:
                        with open(theme_path, 'r') as f:
                            theme_data = json.load(f)
                            custom_themes.append(theme_data)
                    except Exception as e:
                        print(f"❌ Error loading theme {filename}: {e}")
        
        return custom_themes

# ==================== LARGE FILE HANDLER ====================
class LargeFileHandler:
    def __init__(self, editor):
        self.editor = editor
        self.large_file_threshold = 10000
        self.is_large_file = False
        
    def check_file_size(self, content):
        lines = content.count('\n') + 1
        self.is_large_file = lines > self.large_file_threshold
        return self.is_large_file
    
    def optimize_for_large_file(self):
        if self.is_large_file:
            if hasattr(self.editor, 'highlighter'):
                self.editor.highlighter.setDocument(None)
            self.editor.setViewportMargins(0, 0, 0, 0)
            print(f"⚠️ Large file detected. Optimization applied.")
    
    def load_file_in_chunks(self, file_path, callback):
        def load_thread():
            try:
                content = ""
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    lines_loaded = 0
                    for line in f:
                        content += line
                        lines_loaded += 1
                        if lines_loaded % 1000 == 0:
                            self.editor.status_bar.showMessage(f"Loading... {lines_loaded} lines")
                
                QTimer.singleShot(0, lambda: callback(content, lines_loaded))
                
            except Exception as e:
                QTimer.singleShot(0, lambda: self.editor.status_bar.showMessage(f"Error loading file: {e}"))
        
        thread = threading.Thread(target=load_thread)
        thread.daemon = True
        thread.start()

# ==================== CURRENCY SYSTEM ====================
class CurrencySystem:
    def __init__(self, editor):
        self.editor = editor
        self.balance = 100
        self.currency_dir = os.path.dirname(os.path.abspath(__file__))
        self.currency_file = os.path.join(self.currency_dir, "currency.enc")
        print(f"📁 Currency file location: {self.currency_file}")
        self.load_currency()
        
    def load_currency(self):
        try:
            if os.path.exists(self.currency_file):
                with open(self.currency_file, 'r') as f:
                    encoded_data = f.read().strip()
                
                json_data = base64.b64decode(encoded_data.encode()).decode()
                data = json.loads(json_data)
                
                if data.get('signature') == 'ASB_CURRENCY_2024':
                    self.balance = data.get('balance', 100)
            else:
                self.balance = 100
                self.save_currency()
        except Exception as e:
            print(f"❌ Currency load error: {e}")
            self.balance = 100
            self.save_currency()
    
    def save_currency(self):
        data = {
            'balance': self.balance,
            'signature': 'ASB_CURRENCY_2024'
        }
        
        json_data = json.dumps(data)
        encoded_data = base64.b64encode(json_data.encode()).decode()
        
        try:
            with open(self.currency_file, 'w') as f:
                f.write(encoded_data)
            print(f"✅ Currency saved to: {self.currency_file}")
        except Exception as e:
            print(f"❌ Error saving currency: {e}")
    
    def add_money(self, amount, reason=""):
        old_balance = self.balance
        self.balance += amount
        self.save_currency()
        
        if hasattr(self.editor, 'update_status_bar'):
            self.editor.update_status_bar()
        
        print(f"💰 +{amount} coins! ({reason}) Total: {self.balance}")

# ==================== EDITOR CLASSES ====================
class LineNumberArea(QWidget):
    def __init__(self, editor):
        super().__init__(editor)
        self.editor = editor

    def sizeHint(self):
        return QSize(self.editor.line_number_area_width(), 0)

    def paintEvent(self, event):
        self.editor.line_number_area_paint_event(event)

class CodeEditor(QPlainTextEdit):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent_editor = parent
        self.large_file_handler = LargeFileHandler(self)
        self.line_number_area = LineNumberArea(self)
        self.blockCountChanged.connect(self.update_line_number_area_width)
        self.updateRequest.connect(self.update_line_number_area)
        self.cursorPositionChanged.connect(self.highlight_current_line)
        self.update_line_number_area_width(0)
        self.highlight_current_line()

    def line_number_area_width(self):
        if hasattr(self, 'large_file_handler') and self.large_file_handler.is_large_file:
            return 0
        if not self.parent_editor.settings_system.get("line_numbers"):
            return 0
        digits = 1
        count = max(1, self.blockCount())
        while count >= 10:
            count /= 10
            digits += 1
        space = 3 + self.fontMetrics().horizontalAdvance('9') * digits
        return space

    def update_line_number_area_width(self, _):
        self.setViewportMargins(self.line_number_area_width(), 0, 0, 0)

    def update_line_number_area(self, rect, dy):
        if dy:
            self.line_number_area.scroll(0, dy)
        else:
            self.line_number_area.update(0, rect.y(), self.line_number_area.width(), rect.height())
        if rect.contains(self.viewport().rect()):
            self.update_line_number_area_width(0)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        cr = self.contentsRect()
        self.line_number_area.setGeometry(QRect(cr.left(), cr.top(), self.line_number_area_width(), cr.height()))

    def highlight_current_line(self):
        self.setExtraSelections([])

    def line_number_area_paint_event(self, event):
        if hasattr(self, 'large_file_handler') and self.large_file_handler.is_large_file:
            return
        if not self.parent_editor.settings_system.get("line_numbers"):
            return
        painter = QPainter(self.line_number_area)
        painter.fillRect(event.rect(), Qt.lightGray)
        block = self.firstVisibleBlock()
        block_number = block.blockNumber()
        top = self.blockBoundingGeometry(block).translated(self.contentOffset()).top()
        bottom = top + self.blockBoundingRect(block).height()
        while block.isValid() and top <= event.rect().bottom():
            if block.isVisible() and bottom >= event.rect().top():
                number = str(block_number + 1)
                painter.setPen(Qt.black)
                painter.drawText(0, int(top), self.line_number_area.width(), self.fontMetrics().height(),
                                Qt.AlignRight, number)
            block = block.next()
            top = bottom
            bottom = top + self.blockBoundingRect(block).height()
            block_number += 1

    def wheelEvent(self, event):
        if event.modifiers() == Qt.ControlModifier:
            if event.angleDelta().y() > 0:
                self.zoomIn(1)
            else:
                self.zoomOut(1)
            event.accept()
        else:
            super().wheelEvent(event)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Return and event.modifiers() == Qt.ShiftModifier:
            cursor = self.textCursor()
            cursor.insertText("\n")
        else:
            super().keyPressEvent(event)

class FindDialog(QDialog):
    def __init__(self, parent=None, replace_mode=False):
        super().__init__(parent)
        self.replace_mode = replace_mode
        self.setWindowTitle("Find and Replace" if replace_mode else "Find")
        self.setModal(False)
        
        layout = QVBoxLayout(self)
        
        find_layout = QHBoxLayout()
        find_layout.addWidget(QLabel("Find:"))
        self.find_field = QLineEdit()
        self.find_field.textChanged.connect(self.find_text_changed)
        find_layout.addWidget(self.find_field)
        layout.addLayout(find_layout)
        
        if replace_mode:
            replace_layout = QHBoxLayout()
            replace_layout.addWidget(QLabel("Replace:"))
            self.replace_field = QLineEdit()
            replace_layout.addWidget(self.replace_field)
            layout.addLayout(replace_layout)
        
        button_layout = QHBoxLayout()
        if replace_mode:
            self.find_btn = QPushButton("Find Next")
            self.find_btn.clicked.connect(self.find_next)
            self.replace_btn = QPushButton("Replace")
            self.replace_btn.clicked.connect(self.replace)
            self.replace_all_btn = QPushButton("Replace All")
            self.replace_all_btn.clicked.connect(self.replace_all)
            button_layout.addWidget(self.find_btn)
            button_layout.addWidget(self.replace_btn)
            button_layout.addWidget(self.replace_all_btn)
        else:
            self.find_btn = QPushButton("Find Next")
            self.find_btn.clicked.connect(self.find_next)
            button_layout.addWidget(self.find_btn)
        
        self.close_btn = QPushButton("Close")
        self.close_btn.clicked.connect(self.close)
        
        layout.addLayout(button_layout)
        
        self.editor = parent.editor if parent else None
        
    def find_text_changed(self, text):
        if text and self.editor:
            self.find_next()
    
    def find_next(self):
        if not self.editor or not self.find_field.text():
            return
        cursor = self.editor.textCursor()
        document = self.editor.document()
        cursor = document.find(self.find_field.text(), cursor)
        if not cursor.isNull():
            self.editor.setTextCursor(cursor)
        else:
            cursor = QTextCursor(document)
            cursor = document.find(self.find_field.text(), cursor)
            if not cursor.isNull():
                self.editor.setTextCursor(cursor)
            else:
                QMessageBox.information(self, "Find", "Text not found.")
    
    def replace(self):
        if not self.editor or not self.find_field.text():
            return
        cursor = self.editor.textCursor()
        if cursor.hasSelection() and cursor.selectedText() == self.find_field.text():
            cursor.insertText(self.replace_field.text())
        self.find_next()
    
    def replace_all(self):
        if not self.editor or not self.find_field.text():
            return
        cursor = QTextCursor(self.editor.document())
        cursor.beginEditBlock()
        count = 0
        while True:
            cursor = self.editor.document().find(self.find_field.text(), cursor)
            if cursor.isNull():
                break
            cursor.insertText(self.replace_field.text())
            count += 1
        cursor.endEditBlock()
        QMessageBox.information(self, "Replace All", f"Replaced {count} occurrences.")

class GoToLineDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Go to Line")
        self.setModal(True)
        self.setFixedSize(300, 100)
        
        layout = QVBoxLayout(self)
        
        input_layout = QHBoxLayout()
        input_layout.addWidget(QLabel("Line number:"))
        self.line_input = QLineEdit()
        self.line_input.returnPressed.connect(self.go_to_line)
        input_layout.addWidget(self.line_input)
        layout.addLayout(input_layout)
        
        button_layout = QHBoxLayout()
        self.go_btn = QPushButton("Go to Line")
        self.go_btn.clicked.connect(self.go_to_line)
        self.cancel_btn = QPushButton("Cancel")
        self.cancel_btn.clicked.connect(self.close)
        
        button_layout.addWidget(self.go_btn)
        button_layout.addWidget(self.cancel_btn)
        layout.addLayout(button_layout)
        
        self.editor = parent.editor if parent else None
        
    def go_to_line(self):
        if not self.editor:
            return
        try:
            line_number = int(self.line_input.text()) - 1
            document = self.editor.document()
            if line_number < 0 or line_number >= document.blockCount():
                QMessageBox.warning(self, "Go to Line", "Line number out of range!")
                return
            block = document.findBlockByNumber(line_number)
            cursor = QTextCursor(block)
            self.editor.setTextCursor(cursor)
            self.editor.centerCursor()
            self.close()
        except ValueError:
            QMessageBox.warning(self, "Go to Line", "Please enter a valid line number!")

class ASBHighlighter(QSyntaxHighlighter):
    def __init__(self, document):
        super().__init__(document)
        self.rules = []

        keyword_format = QTextCharFormat()
        keyword_format.setForeground(QColor("#569CD6"))
        keyword_format.setFontWeight(QFont.Bold)
        asb_keywords = ["func", "end", "if", "else", "while", "return", "import"]
        for kw in asb_keywords:
            self.rules.append((QRegularExpression(rf"\b{kw}\b"), keyword_format))

        python_keywords = [
            "and", "as", "assert", "async", "await", "break", "class", "continue", 
            "def", "del", "elif", "else", "except", "False", "finally", "for", 
            "from", "global", "if", "import", "in", "is", "lambda", "None", 
            "nonlocal", "not", "or", "pass", "raise", "return", "True", "try", 
            "while", "with", "yield"
        ]
        for kw in python_keywords:
            self.rules.append((QRegularExpression(rf"\b{kw}\b"), keyword_format))

        string_format = QTextCharFormat()
        string_format.setForeground(QColor("#CE9178"))
        self.rules.append((QRegularExpression(r'"[^"]*"'), string_format))
        self.rules.append((QRegularExpression(r"'[^']*'"), string_format))

        comment_format = QTextCharFormat()
        comment_format.setForeground(QColor("#6A9955"))
        self.rules.append((QRegularExpression(r"#.*"), comment_format))

    def highlightBlock(self, text):
        for pattern, fmt in self.rules:
            it = pattern.globalMatch(text)
            while it.hasNext():
                match = it.next()
                self.setFormat(match.capturedStart(), match.capturedLength(), fmt)

# ==================== MAIN EDITOR ====================
class ASBEditor(QMainWindow):
    def __init__(self):
        super().__init__()
        self.settings_system = SettingsSystem(self)
        self.setWindowTitle("ASB Editor - untitled")
        self.resize(1200, 800)
        self.watermark = None
        self.editor = CodeEditor(self)
        self.highlighter = ASBHighlighter(self.editor.document())
        self.file_bar = QToolBar("Open Files")
        self.file_bar.setMovable(False)
        self.file_bar.setIconSize(QSize(16, 16))
        self.file_bar.setStyleSheet("QToolBar { spacing: 1px; padding: 0px; margin: 0px; }")
        self.addToolBar(Qt.TopToolBarArea, self.file_bar)
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("Ready - ASB Editor")
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.addWidget(self.editor)
        self.setCentralWidget(container)
        self.open_files = {}
        self.file_actions = {}
        self.plus_action = None
        self.current_file = "untitled"
        self.last_saved_text = ""
        self.untitled_count = 0
        self.current_theme = "dark"
        self.find_dialog = None
        self.settings_dialog = None
        self.currency_system = CurrencySystem(self)
        self.developer_tools = DeveloperTools(self)
        self.supported_formats = [
            'ASB Files (*.asb)',
            'All Files (*)',
            'Python Files (*.py)',
            'Text Files (*.txt)',
            'JavaScript Files (*.js)',
            'HTML Files (*.html *.htm)',
            'CSS Files (*.css)',
            'JSON Files (*.json)',
            'XML Files (*.xml)',
            'Markdown Files (*.md)',
            'C Files (*.c)',
            'C++ Files (*.cpp *.cc *.cxx)',
            'Java Files (*.java)',
            'PHP Files (*.php)',
            'Ruby Files (*.rb)',
            'Shell Scripts (*.sh *.bash)',
            'Batch Files (*.bat)',
            'Config Files (*.ini *.cfg *.conf)'
        ]
        self.apply_settings()
        self._setup_shortcuts()
        self._build_menubar()
        self._add_file_tab("untitled", "")
        self.editor.cursorPositionChanged.connect(self.update_status_bar)
        if self.settings_system.get("developer_mode"):
            self.status_bar.showMessage("🔓 Developer Mode: Full Access Enabled!")
            self._add_developer_menu()

    def _add_developer_menu(self):
        if self.settings_system.get("developer_mode"):
            menubar = self.menuBar()
            for action in menubar.actions():
                if action.text() == "🔧 Developer":
                    menubar.removeAction(action)
                    break
            self.dev_menu = menubar.addMenu("🔧 Developer")
            debug_menu = self.dev_menu.addMenu("🐛 Debugging")
            sys_info_act = QAction("System Information", self)
            sys_info_act.triggered.connect(self.developer_tools.show_system_info)
            debug_menu.addAction(sys_info_act)
            perf_act = QAction("Performance Monitor", self)
            perf_act.triggered.connect(self.developer_tools.performance_monitor)
            debug_menu.addAction(perf_act)
            debug_info_act = QAction("Show Debug Info", self)
            debug_info_act.triggered.connect(self.show_debug_info)
            debug_menu.addAction(debug_info_act)
            self.dev_menu.addSeparator()
            ui_menu = self.dev_menu.addMenu("🎨 UI Tools")
            reload_ui_act = QAction("Reload UI", self)
            reload_ui_act.triggered.connect(self.reload_ui)
            ui_menu.addAction(reload_ui_act)
            theme_creator_act = QAction("Theme Creator", self)
            theme_creator_act.triggered.connect(self.developer_tools.custom_theme_creator)
            ui_menu.addAction(theme_creator_act)
            self.dev_menu.addSeparator()
            file_menu = self.dev_menu.addMenu("📁 File Operations")
            export_act = QAction("Export All Data", self)
            export_act.triggered.connect(self.developer_tools.export_all_data)
            file_menu.addAction(export_act)
            self.dev_menu.addSeparator()
            system_menu = self.dev_menu.addMenu("⚙️ System Tools")
            restart_act = QAction("Restart Editor", self)
            restart_act.triggered.connect(self.restart_editor)
            system_menu.addAction(restart_act)
            self.dev_menu.addSeparator()
            advanced_menu = self.dev_menu.addMenu("🚀 Advanced")
            inject_code_act = QAction("Code Injection", self)
            inject_code_act.triggered.connect(self.code_injection)
            advanced_menu.addAction(inject_code_act)
            plugin_act = QAction("Plugin System", self)
            plugin_act.triggered.connect(self.plugin_system)
            advanced_menu.addAction(plugin_act)

    def apply_settings(self):
        font_family = self.settings_system.get("font_family")
        font_size = self.settings_system.get("font_size")
        font = QFont(font_family, font_size)
        self.editor.setFont(font)
        print(f"✅ Font applied: {font_family} {font_size}pt")
        if self.settings_system.get("word_wrap"):
            self.editor.setLineWrapMode(QPlainTextEdit.WidgetWidth)
        else:
            self.editor.setLineWrapMode(QPlainTextEdit.NoWrap)
        self.current_theme = self.settings_system.get("theme")
        self.apply_theme()
        self.editor.large_file_handler.large_file_threshold = self.settings_system.get("large_file_threshold")
        if self.settings_system.get("developer_mode"):
            self._add_developer_menu()

    def show_settings(self):
        if not self.settings_dialog:
            self.settings_dialog = SettingsDialog(self)
        self.settings_dialog.exec()

    def resizeEvent(self, event):
        super().resizeEvent(event)

    def update_status_bar(self):
        cursor = self.editor.textCursor()
        line = cursor.blockNumber() + 1
        col = cursor.columnNumber() + 1
        coins = self.currency_system.balance
        if self.settings_system.get("developer_mode"):
            self.status_bar.showMessage(f"🔓 DEV MODE | Line {line}, Column {col} | Coins: {coins} | ASB Editor")
        else:
            self.status_bar.showMessage(f"Line {line}, Column {col} | Coins: {coins} | ASB Editor")

    def _setup_shortcuts(self):
        find_shortcut = QKeySequence("Ctrl+F")
        self.find_action = QAction("Find", self)
        self.find_action.setShortcut(find_shortcut)
        self.find_action.triggered.connect(self.find_text)
        self.addAction(self.find_action)
        replace_shortcut = QKeySequence("Ctrl+H")
        self.replace_action = QAction("Replace", self)
        self.replace_action.setShortcut(replace_shortcut)
        self.replace_action.triggered.connect(self.replace_text)
        self.addAction(self.replace_action)
        save_shortcut = QKeySequence("Ctrl+S")
        self.save_shortcut_action = QAction("Save", self)
        self.save_shortcut_action.setShortcut(save_shortcut)
        self.save_shortcut_action.triggered.connect(self.save_file)
        self.addAction(self.save_shortcut_action)
        open_shortcut = QKeySequence("Ctrl+O")
        self.open_shortcut_action = QAction("Open", self)
        self.open_shortcut_action.setShortcut(open_shortcut)
        self.open_shortcut_action.triggered.connect(self.open_file)
        self.addAction(self.open_shortcut_action)
        goto_shortcut = QKeySequence("Ctrl+G")
        self.goto_action = QAction("Go to Line", self)
        self.goto_action.setShortcut(goto_shortcut)
        self.goto_action.triggered.connect(self.go_to_line)
        self.addAction(self.goto_action)
        next_tab_shortcut = QKeySequence("Ctrl+Tab")
        self.next_tab_action = QAction("Next Tab", self)
        self.next_tab_action.setShortcut(next_tab_shortcut)
        self.next_tab_action.triggered.connect(self.next_tab)
        self.addAction(self.next_tab_action)
        prev_tab_shortcut = QKeySequence("Ctrl+Shift+Tab")
        self.prev_tab_action = QAction("Previous Tab", self)
        self.prev_tab_action.setShortcut(prev_tab_shortcut)
        self.prev_tab_action.triggered.connect(self.prev_tab)
        self.addAction(self.prev_tab_action)
        run_shortcut = QKeySequence("Ctrl+R")
        self.run_action = QAction("Run Python File", self)
        self.run_action.setShortcut(run_shortcut)
        self.run_action.triggered.connect(self.run_python_file)
        self.addAction(self.run_action)
        duplicate_shortcut = QKeySequence("Ctrl+D")
        self.duplicate_action = QAction("Duplicate Line", self)
        self.duplicate_action.setShortcut(duplicate_shortcut)
        self.duplicate_action.triggered.connect(self.duplicate_line)
        self.addAction(self.duplicate_action)
        copy_path_shortcut = QKeySequence("Ctrl+Alt+C")
        self.copy_path_action = QAction("Copy File Path", self)
        self.copy_path_action.setShortcut(copy_path_shortcut)
        self.copy_path_action.triggered.connect(self.copy_file_path)
        self.addAction(self.copy_path_action)
        settings_shortcut = QKeySequence("Ctrl+,")
        self.settings_action = QAction("Settings", self)
        self.settings_action.setShortcut(settings_shortcut)
        self.settings_action.triggered.connect(self.show_settings)
        self.addAction(self.settings_action)

    def _build_menubar(self):
        menubar = self.menuBar()
        file_menu = menubar.addMenu("File")
        new_act = QAction("New File", self)
        new_act.triggered.connect(self._new_untitled_file)
        file_menu.addAction(new_act)
        open_act = QAction("Open File", self)
        open_act.triggered.connect(self.open_file)
        file_menu.addAction(open_act)
        save_act = QAction("Save File", self)
        save_act.triggered.connect(self.save_file)
        file_menu.addAction(save_act)
        self.run_menu_act = QAction("Run Python File", self)
        self.run_menu_act.triggered.connect(self.run_python_file)
        file_menu.addAction(self.run_menu_act)
        file_menu.addSeparator()
        settings_act = QAction("Settings", self)
        settings_act.triggered.connect(self.show_settings)
        file_menu.addAction(settings_act)
        edit_menu = menubar.addMenu("Edit")
        edit_menu.addAction(self.duplicate_action)
        edit_menu.addAction(self.copy_path_action)
        
        # Enhanced Themes menu with custom themes
        theme_menu = menubar.addMenu("Themes")
        
        # Built-in themes
        dark_theme_act = QAction("Dark Theme", self)
        dark_theme_act.triggered.connect(lambda: self.set_theme("dark"))
        theme_menu.addAction(dark_theme_act)
        
        light_theme_act = QAction("Light Theme", self)
        light_theme_act.triggered.connect(lambda: self.set_theme("light"))
        theme_menu.addAction(light_theme_act)
        
        blue_theme_act = QAction("Blue Theme", self)
        blue_theme_act.triggered.connect(lambda: self.set_theme("blue"))
        theme_menu.addAction(blue_theme_act)
        
        monokai_theme_act = QAction("Monokai Theme", self)
        monokai_theme_act.triggered.connect(lambda: self.set_theme("monokai"))
        theme_menu.addAction(monokai_theme_act)
        
        gold_theme_act = QAction("Gold Theme", self)
        gold_theme_act.triggered.connect(lambda: self.set_theme("gold"))
        theme_menu.addAction(gold_theme_act)
        
        light_blue_theme_act = QAction("Light Blue Theme", self)
        light_blue_theme_act.triggered.connect(lambda: self.set_theme("light_blue"))
        theme_menu.addAction(light_blue_theme_act)
        
        red_theme_act = QAction("Red Theme", self)
        red_theme_act.triggered.connect(lambda: self.set_theme("red"))
        theme_menu.addAction(red_theme_act)
        
        lime_theme_act = QAction("Lime Theme", self)
        lime_theme_act.triggered.connect(lambda: self.set_theme("lime"))
        theme_menu.addAction(lime_theme_act)
        
        # Custom themes section
        theme_menu.addSeparator()
        custom_themes_header = QAction("🎨 Custom Themes", self)
        custom_themes_header.setEnabled(False)
        theme_menu.addAction(custom_themes_header)
        
        # Load and add custom themes
        self.load_custom_themes_to_menu(theme_menu)
        
        # Refresh custom themes action
        refresh_themes_act = QAction("🔄 Refresh Custom Themes", self)
        refresh_themes_act.triggered.connect(lambda: self.load_custom_themes_to_menu(theme_menu, refresh=True))
        theme_menu.addAction(refresh_themes_act)
        
        if self.settings_system.get("developer_mode"):
            self._add_developer_menu()
            
        exit_act = QAction("Exit", self)
        exit_act.triggered.connect(self.close)
        file_menu.addAction(exit_act)

    def load_custom_themes_to_menu(self, theme_menu, refresh=False):
        """Load custom themes and add them to the themes menu"""
        if refresh:
            # Remove existing custom themes (except built-in ones and separators)
            actions_to_remove = []
            for action in theme_menu.actions():
                if action.text().startswith("🎨") or action.text().startswith("🔄"):
                    continue
                if action.text() not in ["Dark Theme", "Light Theme", "Blue Theme", "Monokai Theme", 
                                       "Gold Theme", "Light Blue Theme", "Red Theme", "Lime Theme"]:
                    actions_to_remove.append(action)
            
            for action in actions_to_remove:
                theme_menu.removeAction(action)
        
        # Load custom themes
        custom_themes = self.developer_tools.load_custom_themes()
        
        for theme_data in custom_themes:
            theme_name = theme_data.get("name", "Unnamed Theme")
            theme_act = QAction(f"🎨 {theme_name}", self)
            theme_act.triggered.connect(lambda checked, t=theme_data: self.apply_custom_theme(t))
            theme_menu.addAction(theme_act)

    def apply_custom_theme(self, theme_data):
        """Apply a custom theme from theme data"""
        try:
            css = theme_data.get("css", "")
            self.editor.setStyleSheet(css)
            self.setStyleSheet(css)
            self.current_theme = f"custom_{theme_data.get('name', 'unknown')}"
            self.settings_system.set("theme", self.current_theme)
            
            # Update file tabs styling
            for name, action in self.file_actions.items():
                widget = action.defaultWidget()
                if widget:
                    label = widget.findChild(QLabel)
                    if label:
                        # Extract background color from CSS for tab styling
                        if "background:" in css:
                            bg_start = css.find("background:") + 11
                            bg_end = css.find(";", bg_start)
                            if bg_end != -1:
                                bg_color = css[bg_start:bg_end].strip()
                                label.setStyleSheet(f"color:white; padding: 2px; background: {self._darken_color(bg_color)}; border-radius: 3px;")
            
            QMessageBox.information(self, "Theme Applied", f"🎨 Applied custom theme: {theme_data.get('name', 'Unknown')}")
        except Exception as e:
            QMessageBox.warning(self, "Theme Error", f"Could not apply theme: {e}")

    def _darken_color(self, color_hex, factor=0.8):
        """Darken a hex color for tab backgrounds"""
        try:
            color = QColor(color_hex)
            color = color.darker(int(100 + (100 - 100 * factor)))
            return color.name()
        except:
            return "#2d2d30"  # Fallback color

    def reload_ui(self):
        if self.settings_system.get("developer_mode"):
            self.apply_settings()
            QMessageBox.information(self, "Developer", "🔄 UI reloaded with all settings applied!")
        else:
            QMessageBox.warning(self, "Access Denied", "Developer mode required!")

    def show_debug_info(self):
        if self.settings_system.get("developer_mode"):
            debug_info = f"""
🐛 COMPREHENSIVE DEBUG INFORMATION:

📁 FILE SYSTEM:
• Open Files: {len(self.open_files)}
• Current File: {self.current_file}
• Files: {list(self.open_files.keys())}

🎨 UI STATE:
• Theme: {self.current_theme}
• Font: {self.settings_system.get('font_family')} {self.settings_system.get('font_size')}pt
• Line Numbers: {self.settings_system.get('line_numbers')}
• Word Wrap: {self.settings_system.get('word_wrap')}

🔧 SYSTEM:
• Developer Mode: {self.settings_system.get('developer_mode')}
• Multi-process: {self.settings_system.get('enable_multiprocess')}
• Auto Save: {self.settings_system.get('auto_save')}
• Coins: {self.currency_system.balance}

⚡ PERFORMANCE:
• Large File Threshold: {self.settings_system.get('large_file_threshold')} lines
• Tab Size: {self.settings_system.get('tab_size')} spaces
"""
            QMessageBox.information(self, "Debug Info", debug_info)
        else:
            QMessageBox.warning(self, "Access Denied", "Developer mode required!")

    def restart_editor(self):
        if self.settings_system.get("developer_mode"):
            reply = QMessageBox.question(self, "Restart Editor", 
                                       "Are you sure you want to restart the editor?",
                                       QMessageBox.Yes | QMessageBox.No)
            if reply == QMessageBox.Yes:
                QApplication.quit()
                subprocess.Popen([sys.executable] + sys.argv)
        else:
            QMessageBox.warning(self, "Access Denied", "Developer mode required!")

    def code_injection(self):
        if self.settings_system.get("developer_mode"):
            code, ok = QInputDialog.getMultiLineText(self, "Code Injection", 
                                                   "Enter Python code to execute:", 
                                                   "print('Hello from injected code!')")
            if ok and code:
                try:
                    exec(code)
                    QMessageBox.information(self, "Code Injection", "✅ Code executed successfully!")
                except Exception as e:
                    QMessageBox.warning(self, "Code Injection Error", f"❌ Error: {e}")
        else:
            QMessageBox.warning(self, "Access Denied", "Developer mode required!")

    def plugin_system(self):
        if self.settings_system.get("developer_mode"):
            QMessageBox.information(self, "Plugin System", 
                                  "🚧 Plugin System Under Development!\n\n"
                                  "This will allow you to:\n"
                                  "• Load external plugins\n• Create custom features\n"
                                  "• Extend editor functionality\n• Share plugins with others")
        else:
            QMessageBox.warning(self, "Access Denied", "Developer mode required!")

    def set_theme(self, theme_name):
        self.current_theme = theme_name
        self.settings_system.set("theme", theme_name)
        self.apply_theme()

    def apply_theme(self):
        if self.current_theme == "dark":
            self.editor.setStyleSheet(
                "background:#1e1e1e; color:#d4d4d4; font-family:Consolas; font-size:12pt;"
            )
            self.setStyleSheet("""
                QMainWindow { background:#252526; } 
                QMenuBar { background:#333; color:white; border: none; }
                QMenuBar::item { background: transparent; padding: 5px 10px; }
                QMenuBar::item:selected { background: #505050; }
                QMenu { background:#333; color:white; border: 1px solid #555; }
                QMenu::item { padding: 5px 20px; }
                QMenu::item:selected { background: #505050; }
                QToolBar { background:#333; border: none; padding: 2px; }
                QStatusBar { background:#333; color:white; }
            """)
        elif self.current_theme == "light":
            self.editor.setStyleSheet(
                "background:#ffffff; color:#000000; font-family:Consolas; font-size:12pt;"
            )
            self.setStyleSheet("""
                QMainWindow { background:#f0f0f0; } 
                QMenuBar { background:#ddd; color:black; border: none; }
                QMenuBar::item { background: transparent; padding: 5px 10px; }
                QMenuBar::item:selected { background: #bbb; }
                QMenu { background:#eee; color:black; border: 1px solid #ccc; }
                QMenu::item { padding: 5px 20px; }
                QMenu::item:selected { background: #ddd; }
                QToolBar { background:#ddd; border: none; padding: 2px; }
                QStatusBar { background:#ddd; color:black; }
            """)
        elif self.current_theme == "blue":
            self.editor.setStyleSheet(
                "background:#1c2b4a; color:#e1e1e6; font-family:Consolas; font-size:12pt;"
            )
            self.setStyleSheet("""
                QMainWindow { background:#2d3b55; } 
                QMenuBar { background:#3a4a65; color:white; border: none; }
                QMenuBar::item { background: transparent; padding: 5px 10px; }
                QMenuBar::item:selected { background: #4a5a75; }
                QMenu { background:#3a4a65; color:white; border: 1px solid #4a5a75; }
                QMenu::item { padding: 5px 20px; }
                QMenu::item:selected { background: #4a5a75; }
                QToolBar { background:#3a4a65; border: none; padding: 2px; }
                QStatusBar { background:#3a4a65; color:white; }
            """)
        elif self.current_theme == "monokai":
            self.editor.setStyleSheet(
                "background:#272822; color:#f8f8f2; font-family:Consolas; font-size:12pt;"
            )
            self.setStyleSheet("""
                QMainWindow { background:#2e2e2e; } 
                QMenuBar { background:#3e3d32; color:#f8f8f2; border: none; }
                QMenuBar::item { background: transparent; padding: 5px 10px; }
                QMenuBar::item:selected { background: #4e4d42; }
                QMenu { background:#3e3d32; color:#f8f8f2; border: 1px solid #4e4d42; }
                QMenu::item { padding: 5px 20px; }
                QMenu::item:selected { background: #4e4d42; }
                QToolBar { background:#3e3d32; border: none; padding: 2px; }
                QStatusBar { background:#3e3d32; color:#f8f8f2; }
            """)
        elif self.current_theme == "gold":
            self.editor.setStyleSheet(
                "background:#2d1c0a; color:#ffd700; font-family:Consolas; font-size:12pt;"
            )
            self.setStyleSheet("""
                QMainWindow { background:#3d2c1a; } 
                QMenuBar { background:#4d3c2a; color:#ffd700; border: none; }
                QMenuBar::item { background: transparent; padding: 5px 10px; }
                QMenuBar::item:selected { background: #5d4c3a; }
                QMenu { background:#4d3c2a; color:#ffd700; border: 1px solid #5d4c3a; }
                QMenu::item { padding: 5px 20px; }
                QMenu::item:selected { background: #5d4c3a; }
                QToolBar { background:#4d3c2a; border: none; padding: 2px; }
                QStatusBar { background:#4d3c2a; color:#ffd700; }
            """)
        elif self.current_theme == "light_blue":
            self.editor.setStyleSheet(
                "background:#e6f7ff; color:#0066cc; font-family:Consolas; font-size:12pt;"
            )
            self.setStyleSheet("""
                QMainWindow { background:#d6e7ff; } 
                QMenuBar { background:#c6d7ff; color:#0066cc; border: none; }
                QMenuBar::item { background: transparent; padding: 5px 10px; }
                QMenuBar::item:selected { background: #b6c7ff; }
                QMenu { background:#c6d7ff; color:#0066cc; border: 1px solid #b6c7ff; }
                QMenu::item { padding: 5px 20px; }
                QMenu::item:selected { background: #b6c7ff; }
                QToolBar { background:#c6d7ff; border: none; padding: 2px; }
                QStatusBar { background:#c6d7ff; color:#0066cc; }
            """)
        elif self.current_theme == "red":
            self.editor.setStyleSheet(
                "background:#2a0f0f; color:#ff6b6b; font-family:Consolas; font-size:12pt;"
            )
            self.setStyleSheet("""
                QMainWindow { background:#3a1f1f; } 
                QMenuBar { background:#4a2f2f; color:#ff6b6b; border: none; }
                QMenuBar::item { background: transparent; padding: 5px 10px; }
                QMenuBar::item:selected { background: #5a3f3f; }
                QMenu { background:#4a2f2f; color:#ff6b6b; border: 1px solid #5a3f3f; }
                QMenu::item { padding: 5px 20px; }
                QMenu::item:selected { background: #5a3f3f; }
                QToolBar { background:#4a2f2f; border: none; padding: 2px; }
                QStatusBar { background:#4a2f2f; color:#ff6b6b; }
            """)
        elif self.current_theme == "lime":
            self.editor.setStyleSheet(
                "background:#0f2a0f; color:#90ee90; font-family:Consolas; font-size:12pt;"
            )
            self.setStyleSheet("""
                QMainWindow { background:#1f3a1f; } 
                QMenuBar { background:#2f4a2f; color:#90ee90; border: none; }
                QMenuBar::item { background: transparent; padding: 5px 10px; }
                QMenuBar::item:selected { background: #3f5a3f; }
                QMenu { background:#2f4a2f; color:#90ee90; border: 1px solid #3f5a3f; }
                QMenu::item { padding: 5px 20px; }
                QMenu::item:selected { background: #3f5a3f; }
                QToolBar { background:#2f4a2f; border: none; padding: 2px; }
                QStatusBar { background:#2f4a2f; color:#90ee90; }
            """)
        for name, action in self.file_actions.items():
            widget = action.defaultWidget()
            if widget:
                label = widget.findChild(QLabel)
                if label:
                    if self.current_theme in ["dark", "blue", "monokai", "gold", "red", "lime"]:
                        label.setStyleSheet("color:white; padding: 2px; background: #2d2d30; border-radius: 3px;")
                    else:
                        label.setStyleSheet("color:black; padding: 2px; background: #e8e8e8; border-radius: 3px;")

    def _add_file_tab(self, name, content):
        if self.plus_action:
            self.file_bar.removeAction(self.plus_action)
            self.plus_action = None
        tab = QWidget()
        layout = QHBoxLayout(tab)
        layout.setContentsMargins(5, 0, 5, 0)
        layout.setSpacing(2)
        display_name = os.path.basename(name) if os.path.isfile(name) else name
        label = QLabel(display_name)
        if self.current_theme in ["dark", "blue", "monokai", "gold", "red", "lime"]:
            label.setStyleSheet("color:white; padding: 2px; background: #2d2d30; border-radius: 3px;")
        else:
            label.setStyleSheet("color:black; padding: 2px; background: #e8e8e8; border-radius: 3px;")
        label.mousePressEvent = lambda e: self._switch_to_file(name)
        close_btn = QPushButton("×")
        close_btn.setFixedSize(16, 16)
        close_btn.setStyleSheet("""
            QPushButton { 
                border: none; 
                background: transparent; 
                font-weight: bold;
                color: #ff4444;
                font-size: 12px;
            }
            QPushButton:hover { 
                background: #ff4444; 
                color: white;
                border-radius: 8px;
            }
        """)
        close_btn.clicked.connect(lambda: self._close_file(name))
        layout.addWidget(label)
        layout.addWidget(close_btn)
        action = QWidgetAction(self)
        action.setDefaultWidget(tab)
        self.file_bar.addAction(action)
        self.file_actions[name] = action
        self.open_files[name] = content
        self._switch_to_file(name)
        self.plus_action = QAction("+ New", self)
        self.plus_action.triggered.connect(self._new_untitled_file)
        self.file_bar.addAction(self.plus_action)

    def _switch_to_file(self, name):
        if name in self.open_files:
            if self.current_file in self.open_files:
                self.open_files[self.current_file] = self.editor.toPlainText()
            self.editor.setPlainText(self.open_files[name])
            self.current_file = name
            self.last_saved_text = self.open_files[name]
            if os.path.isfile(name):
                self.setWindowTitle(f"ASB Editor - {name}")
            else:
                self.setWindowTitle(f"ASB Editor - {name}")
            lines = self.editor.document().blockCount()
            coins = self.currency_system.balance
            self.status_bar.showMessage(f"Line 1, Column 1 | {lines} lines | Coins: {coins}")

    def _close_file(self, name):
        if self.current_file in self.open_files:
            self.open_files[self.current_file] = self.editor.toPlainText()
        current_text = self.open_files.get(name, "")
        if name == self.current_file and current_text != self.last_saved_text:
            msg = QMessageBox(self)
            msg.setIcon(QMessageBox.Question)
            msg.setWindowTitle("Unsaved Changes")
            msg.setText(f"Do you want to save changes to {name}?")
            msg.setStandardButtons(QMessageBox.Save | QMessageBox.Discard | QMessageBox.Cancel)
            choice = msg.exec()
            if choice == QMessageBox.Save:
                self.save_file()
            elif choice == QMessageBox.Cancel:
                return
        if name in self.file_actions:
            self.file_bar.removeAction(self.file_actions[name])
            del self.file_actions[name]
        self.open_files.pop(name, None)
        if self.open_files:
            next_name = list(self.open_files.keys())[0]
            self._switch_to_file(next_name)
        else:
            self._new_untitled_file()

    def _new_untitled_file(self):
        self.untitled_count += 1
        name = f"untitled_{self.untitled_count}"
        self._add_file_tab(name, "")

    def open_file(self):
        default_filter = self.settings_system.get("default_file_type")
        formats = ";;".join(self.supported_formats)
        path, selected_filter = QFileDialog.getOpenFileName(
            self, "Open file", filter=formats, initialFilter=default_filter
        )
        if path:
            try:
                with open(path, "r", encoding="utf-8") as f:
                    sample_content = f.read(10000)
                    f.seek(0)
                    if self.editor.large_file_handler.check_file_size(f.read()):
                        self.status_bar.showMessage("🔄 Loading large file...")
                        self.editor.large_file_handler.load_file_in_chunks(
                            path, 
                            lambda content, line_count: self._on_large_file_loaded(path, content, line_count)
                        )
                    else:
                        f.seek(0)
                        text = f.read()
                        if len(self.open_files) == 1 and "untitled" in self.open_files and self.open_files["untitled"] == "":
                            self._close_file("untitled")
                        self._add_file_tab(path, text)
            except Exception as e:
                QMessageBox.critical(self, "Error", str(e))

    def _on_large_file_loaded(self, path, content, line_count):
        if len(self.open_files) == 1 and "untitled" in self.open_files and self.open_files["untitled"] == "":
            self._close_file("untitled")
        self._add_file_tab(path, content)
        self.editor.large_file_handler.optimize_for_large_file()
        self.status_bar.showMessage(f"✅ Large file loaded: {line_count} lines")

    def save_file(self):
        text = self.editor.toPlainText()
        if self.current_file and os.path.isfile(self.current_file):
            try:
                with open(self.current_file, "w", encoding="utf-8") as f:
                    f.write(text)
                    self.last_saved_text = text
                    self.open_files[self.current_file] = text
            except Exception as e:
                QMessageBox.critical(self, "Error", str(e))
        else:
            default_filter = self.settings_system.get("default_file_type")
            formats = ";;".join(self.supported_formats)
            path, selected_filter = QFileDialog.getSaveFileName(
                self, "Save file", filter=formats, initialFilter=default_filter
            )
            if path:
                if selected_filter == 'ASB Files (*.asb)' and not path.endswith('.asb'):
                    path += '.asb'
                try:
                    with open(path, "w", encoding="utf-8") as f:
                        f.write(text)
                        self.last_saved_text = text
                        if self.current_file in self.open_files:
                            self.open_files.pop(self.current_file)
                        if self.current_file in self.file_actions:
                            self.file_bar.removeAction(self.file_actions[self.current_file])
                            del self.file_actions[self.current_file]
                        self.current_file = path
                        self.open_files[path] = text
                        self.setWindowTitle(f"ASB Editor - {path}")
                        self._add_file_tab(path, text)
                except Exception as e:
                    QMessageBox.critical(self, "Error", str(e))

    def find_text(self):
        if self.find_dialog:
            self.find_dialog.close()
        self.find_dialog = FindDialog(self, replace_mode=False)
        self.find_dialog.show()
        self.find_dialog.raise_()
        self.find_dialog.find_field.setFocus()

    def replace_text(self):
        if self.find_dialog:
            self.find_dialog.close()
        self.find_dialog = FindDialog(self, replace_mode=True)
        self.find_dialog.show()
        self.find_dialog.raise_()
        self.find_dialog.find_field.setFocus()

    def run_python_file(self):
        if not self.current_file.lower().endswith('.py'):
            QMessageBox.information(self, "Run", "Can only run Python (.py) files!")
            return
        if not os.path.isfile(self.current_file):
            QMessageBox.warning(self, "Run", "Please save the file before running!")
            return
        try:
            self.save_file()
            file_dir = os.path.dirname(self.current_file)
            file_name = os.path.basename(self.current_file)
            if self.settings_system.get("enable_multiprocess"):
                self._run_in_separate_process(file_dir, file_name)
            else:
                self._run_in_current_process(file_dir, file_name)
        except Exception as e:
            QMessageBox.critical(self, "Run Error", f"Failed to run Python file:\n{str(e)}")

    def _run_in_separate_process(self, file_dir, file_name):
        def run_process():
            try:
                if os.name == 'nt':
                    cmd = f'cd /d "{file_dir}" && python "{file_name}"'
                    subprocess.run(cmd, shell=True, check=True)
                else:
                    cmd = f'cd "{file_dir}" && python3 "{file_name}"'
                    subprocess.run(cmd, shell=True, check=True, executable='/bin/bash')
            except subprocess.CalledProcessError as e:
                print(f"❌ Process error: {e}")
        thread = threading.Thread(target=run_process)
        thread.daemon = True
        thread.start()
        self.status_bar.showMessage("🔄 Running Python file in separate process...")

    def _run_in_current_process(self, file_dir, file_name):
        if os.name == 'nt':
            cmd = f'cmd /k "cd /d "{file_dir}" && python "{file_name}" && echo. && echo Program finished. Press any key to close... && pause >nul"'
            subprocess.Popen(['start', 'cmd', '/c', cmd], shell=True)
        else:
            cmd = f'cd "{file_dir}" && python3 "{file_name}" && echo && echo "Program finished. Press any key to close..." && read -n 1'
            subprocess.Popen(['xterm', '-e', 'bash', '-c', cmd])

    def duplicate_line(self):
        cursor = self.editor.textCursor()
        cursor.select(QTextCursor.LineUnderCursor)
        text = cursor.selectedText()
        cursor.movePosition(QTextCursor.EndOfLine)
        cursor.insertText("\n" + text)

    def copy_file_path(self):
        if self.current_file and os.path.isfile(self.current_file):
            clipboard = QApplication.clipboard()
            clipboard.setText(self.current_file)

    def next_tab(self):
        if len(self.open_files) > 1:
            files = list(self.open_files.keys())
            current_index = files.index(self.current_file)
            next_index = (current_index + 1) % len(files)
            self._switch_to_file(files[next_index])

    def prev_tab(self):
        if len(self.open_files) > 1:
            files = list(self.open_files.keys())
            current_index = files.index(self.current_file)
            prev_index = (current_index - 1) % len(files)
            self._switch_to_file(files[prev_index])

    def go_to_line(self):
        dialog = GoToLineDialog(self)
        dialog.exec()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    win = ASBEditor()
    win.show()
    sys.exit(app.exec())