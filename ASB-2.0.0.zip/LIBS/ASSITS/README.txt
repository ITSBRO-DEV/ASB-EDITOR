THIS FILE IS CRITICAL!

 if you remove this file the editor might not work!
 this is the hole editor if you just edit a thing
 and the developer password is just a little thing you can like reload ui and other things!