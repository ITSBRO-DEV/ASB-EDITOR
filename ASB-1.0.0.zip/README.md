**ASMP-EDITOR**
*the new editor*


***.py format is*** *boring*
**thats why we made** ***.ASB***




**NOTE :** *after useing this make sure to run* ***install.bat***
*then go to python-file/dist then run* **editor.exe**
**DONT REMOVE ANY FILES FROM THE FOLDER**
