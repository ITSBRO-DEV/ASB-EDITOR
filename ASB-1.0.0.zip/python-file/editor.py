# pip install PySide6
import sys, os
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QFileDialog, QPlainTextEdit,
    QVBoxLayout, QWidget, QMessageBox, QMenuBar, QMenu,
    QWidgetAction, QSizePolicy, QToolBar, QHBoxLayout, QLabel, QPushButton
)
from PySide6.QtGui import QAction, QSyntaxHighlighter, QTextCharFormat, QColor, QFont
from PySide6.QtCore import Qt, QRegularExpression

class ASBHighlighter(QSyntaxHighlighter):
    def __init__(self, document):
        super().__init__(document)
        self.rules = []

        keyword_format = QTextCharFormat()
        keyword_format.setForeground(QColor("#569CD6"))
        keyword_format.setFontWeight(QFont.Bold)
        keywords = ["func", "end", "if", "else", "while", "return", "import"]
        for kw in keywords:
            self.rules.append((QRegularExpression(rf"\b{kw}\b"), keyword_format))

        string_format = QTextCharFormat()
        string_format.setForeground(QColor("#CE9178"))
        self.rules.append((QRegularExpression(r'"[^"]*"'), string_format))
        self.rules.append((QRegularExpression(r"'[^']*'"), string_format))

        comment_format = QTextCharFormat()
        comment_format.setForeground(QColor("#6A9955"))
        self.rules.append((QRegularExpression(r"#.*"), comment_format))

    def highlightBlock(self, text):
        for pattern, fmt in self.rules:
            it = pattern.globalMatch(text)
            while it.hasNext():
                match = it.next()
                self.setFormat(match.capturedStart(), match.capturedLength(), fmt)

class ASBEditor(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("ASB Editor - untitled")
        self.resize(1000, 700)

        self.editor = QPlainTextEdit()
        self.highlighter = ASBHighlighter(self.editor.document())

        self.file_bar = QToolBar("Open Files")
        self.file_bar.setMovable(False)
        self.addToolBar(Qt.TopToolBarArea, self.file_bar)

        container = QWidget()
        layout = QVBoxLayout(container)
        layout.addWidget(self.editor)
        self.setCentralWidget(container)

        self.open_files = {}
        self.file_actions = {}
        self.plus_action = None
        self.current_file = "untitled"
        self.last_saved_text = ""
        self.untitled_count = 0
        self.dark_mode = True
        self.apply_theme()

        self._build_menubar()
        self._add_file_tab("untitled", "")

    def _build_menubar(self):
        menubar = self.menuBar()
        file_menu = menubar.addMenu("File")

        new_act = QAction("New File", self)
        new_act.triggered.connect(self._new_untitled_file)
        file_menu.addAction(new_act)

        open_act = QAction("Open File", self)
        open_act.triggered.connect(self.open_file)
        file_menu.addAction(open_act)

        save_act = QAction("Save File", self)
        save_act.triggered.connect(self.save_file)
        file_menu.addAction(save_act)

        exit_act = QAction("Exit", self)
        exit_act.triggered.connect(self.close)
        file_menu.addAction(exit_act)

        spacer = QWidget()
        spacer.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        spacer_action = QWidgetAction(self)
        spacer_action.setDefaultWidget(spacer)
        menubar.addAction(spacer_action)

        self.theme_action = QAction("", self)
        self.theme_action.triggered.connect(self.toggle_theme)
        menubar.addAction(self.theme_action)
        self._update_theme_icon()

    def _update_theme_icon(self):
        self.theme_action.setText("☀️" if self.dark_mode else "🌙")

    def _add_file_tab(self, name, content):
        # Remove existing + button if present
        if self.plus_action:
            self.file_bar.removeAction(self.plus_action)
            self.plus_action = None

        tab = QWidget()
        layout = QHBoxLayout(tab)
        layout.setContentsMargins(5, 0, 5, 0)
        layout.setSpacing(2)

        # Use only the filename for display, not full path
        display_name = os.path.basename(name) if os.path.isfile(name) else name
        label = QLabel(display_name)
        label.setStyleSheet("color:white; padding: 2px;" if self.dark_mode else "color:black; padding: 2px;")
        label.mousePressEvent = lambda e: self._switch_to_file(name)

        close_btn = QPushButton("×")
        close_btn.setFixedSize(16, 16)
        close_btn.setStyleSheet("""
            QPushButton { 
                border: none; 
                background: transparent; 
                font-weight: bold;
                color: #ff4444;
            }
            QPushButton:hover { 
                background: #ff4444; 
                color: white;
                border-radius: 8px;
            }
        """)
        close_btn.clicked.connect(lambda: self._close_file(name))

        layout.addWidget(label)
        layout.addWidget(close_btn)

        action = QWidgetAction(self)
        action.setDefaultWidget(tab)
        self.file_bar.addAction(action)

        self.file_actions[name] = action
        self.open_files[name] = content
        self._switch_to_file(name)

        # Re-add + button at the end
        self.plus_action = QAction("+ New", self)
        self.plus_action.triggered.connect(self._new_untitled_file)
        self.file_bar.addAction(self.plus_action)

    def _switch_to_file(self, name):
        if name in self.open_files:
            # Save current file content before switching
            if self.current_file in self.open_files:
                self.open_files[self.current_file] = self.editor.toPlainText()
            
            self.editor.setPlainText(self.open_files[name])
            self.current_file = name
            self.last_saved_text = self.open_files[name]
            
            # Update window title with full path for saved files, just name for untitled
            if os.path.isfile(name):
                self.setWindowTitle(f"ASB Editor - {name}")
            else:
                self.setWindowTitle(f"ASB Editor - {name}")

    def _close_file(self, name):
        # Save current content before checking for changes
        if self.current_file in self.open_files:
            self.open_files[self.current_file] = self.editor.toPlainText()
            
        current_text = self.open_files.get(name, "")
        if name == self.current_file and current_text != self.last_saved_text:
            msg = QMessageBox(self)
            msg.setIcon(QMessageBox.Question)
            msg.setWindowTitle("Unsaved Changes")
            msg.setText(f"Do you want to save changes to {name}?")
            msg.setStandardButtons(QMessageBox.Save | QMessageBox.Discard | QMessageBox.Cancel)
            choice = msg.exec()

            if choice == QMessageBox.Save:
                self.save_file()
            elif choice == QMessageBox.Cancel:
                return  # Don't close the file

        if name in self.file_actions:
            self.file_bar.removeAction(self.file_actions[name])
            del self.file_actions[name]

        self.open_files.pop(name, None)

        if self.open_files:
            next_name = list(self.open_files.keys())[0]
            self._switch_to_file(next_name)
        else:
            # When no files are open, create a new untitled file instead of leaving empty
            self._new_untitled_file()

    def _new_untitled_file(self):
        self.untitled_count += 1
        name = f"untitled_{self.untitled_count}"
        self._add_file_tab(name, "")

    def open_file(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Open .asb file", filter="ASB Files (*.asb)"
        )
        if path:
            if not path.lower().endswith(".asb"):
                QMessageBox.critical(self, "Error", "Unsupported file type!")
                return
            try:
                with open(path, "r", encoding="utf-8") as f:
                    text = f.read()
                    # If we only have the initial untitled file with no content, replace it
                    if len(self.open_files) == 1 and "untitled" in self.open_files and self.open_files["untitled"] == "":
                        self._close_file("untitled")
                    self._add_file_tab(path, text)
            except Exception as e:
                QMessageBox.critical(self, "Error", str(e))

    def save_file(self):
        text = self.editor.toPlainText()
        if self.current_file and os.path.isfile(self.current_file):
            try:
                with open(self.current_file, "w", encoding="utf-8") as f:
                    f.write(text)
                    self.last_saved_text = text
                    self.open_files[self.current_file] = text
                QMessageBox.information(self, "Saved", f"Saved to {self.current_file}")
            except Exception as e:
                QMessageBox.critical(self, "Error", str(e))
        else:
            path, _ = QFileDialog.getSaveFileName(
                self, "Save .asb file", filter="ASB Files (*.asb)"
            )
            if path:
                try:
                    with open(path, "w", encoding="utf-8") as f:
                        f.write(text)
                        self.last_saved_text = text
                        # Remove old untitled file if it exists
                        if self.current_file in self.open_files:
                            self.open_files.pop(self.current_file)
                        if self.current_file in self.file_actions:
                            self.file_bar.removeAction(self.file_actions[self.current_file])
                            del self.file_actions[self.current_file]
                            
                        self.current_file = path
                        self.open_files[path] = text
                        self.setWindowTitle(f"ASB Editor - {path}")
                        self._add_file_tab(path, text)
                    QMessageBox.information(self, "Saved", f"Saved to {path}")
                except Exception as e:
                    QMessageBox.critical(self, "Error", str(e))

    def apply_theme(self):
        if self.dark_mode:
            self.editor.setStyleSheet(
                "background:#1e1e1e; color:#d4d4d4; font-family:Consolas; font-size:12pt;"
            )
            self.setStyleSheet("QMainWindow { background:#252526; } "
                               "QMenuBar { background:#333; color:white; } "
                               "QMenu { background:#333; color:white; }"
                               "QToolBar { background:#333; border:none; }")
        else:
            self.editor.setStyleSheet(
                "background:#ffffff; color:#000000; font-family:Consolas; font-size:12pt;"
            )
            self.setStyleSheet("QMainWindow { background:#f0f0f0; } "
                               "QMenuBar { background:#ddd; color:black; } "
                               "QMenu { background:#eee; color:black; }"
                               "QToolBar { background:#ddd; border:none; }")

    def toggle_theme(self):
        self.dark_mode = not self.dark_mode
        self.apply_theme()
        self._update_theme_icon()
        # Update all tab labels for theme change
        for name, action in self.file_actions.items():
            widget = action.defaultWidget()
            if widget:
                label = widget.findChild(QLabel)
                if label:
                    label.setStyleSheet("color:white;" if self.dark_mode else "color:black;")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    win = ASBEditor()
    win.show()
    sys.exit(app.exec())